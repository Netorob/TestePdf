package com.fourcatsdev.aula08.controller;

import java.io.IOException;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.fourcatsdev.aula08.service.GeradorPDFService;

import br.edu.ifms.geradorPDF.service.GeradorPdfService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class GeradorPdfController {
	private final GeradorPDFService geradorPdfService;

	public GeradorPdfController(GeradorPDFService geradorPdfService) {
		this.geradorPdfService = geradorPdfService;
	}
	
	@GetMapping("/usuario/pdf")
	public void generatePDF(HttpServletResponse response) throws IOException {
		response.setContentType("relatorio/pdf");

        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename= relatorio"  + ".pdf";
        response.setHeader(headerKey, headerValue);

        this.geradorPdfService.exportar(response);
    }
}


