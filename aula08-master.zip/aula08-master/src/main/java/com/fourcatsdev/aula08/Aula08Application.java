package com.fourcatsdev.aula08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula08Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula08Application.class, args);
	}

}
