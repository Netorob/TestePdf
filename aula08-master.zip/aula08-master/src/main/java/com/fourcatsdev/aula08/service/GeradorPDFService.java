package com.fourcatsdev.aula08.service;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;


import com.lowagie.text.Image;
import com.lowagie.text.ImageLoader;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class GeradorPDFService {
	public void exportar(HttpServletResponse response) throws IOException {
        Document documento = new Document(PageSize.A4); 
        PdfWriter.getInstance(documento, response.getOutputStream());

        documento.open();
        
        documento.setMargins(40f, 40f, 0, 40f);
        
        Image qrCode = Image.getInstance("/Users/lades-mac03/Documents/aula08-master/src/main/resources/imagens/websiteQRCode_noFrame.png");
        qrCode.scalePercent(15);
        
        
        Font fonteParagrafo = FontFactory.getFont(FontFactory.TIMES_BOLD);
        fonteParagrafo.setSize(40); // tamanho da fonte

        Paragraph parCRLV = new Paragraph("22222",fonteParagrafo); // coluna id
        parCRLV.setAlignment(Paragraph.ALIGN_RIGHT);
        
        Paragraph parNome = new Paragraph("roberto neto", fonteParagrafo); // coluna nome
        parNome.setAlignment(Paragraph.ALIGN_RIGHT);

        Paragraph parProcesso= new Paragraph("11111", fonteParagrafo); // coluna cpf
        parProcesso.setAlignment(Paragraph.ALIGN_RIGHT);
        

        documento.add(qrCode);
        
        documento.add(parNome);
        documento.add(parCRLV);
        documento.add(parProcesso);
        
        documento.close();
    }
	
}	
